package home.service;

import java.util.List;

import home.dto.CodeDto;

public interface CodeService {

	List<CodeDto> getCodeList();
	
}