package home.dao;

import java.util.List;

import home.dto.CodeDto;

public interface CodeDao {

	List<CodeDto> getCodeList();

	
}
