package board.dao;


public interface RegisterDao {
	public boolean register(String userName, String userEmail, String userPassword);
}
