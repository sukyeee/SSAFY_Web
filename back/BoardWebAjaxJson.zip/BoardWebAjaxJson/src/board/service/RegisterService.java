package board.service;

import board.dto.UserDto;

public interface RegisterService {
	public boolean register(String userName, String userEmail, String userPassword);
	
	
	
}
