package board.service;

import board.dto.BoardDto;

public interface InsertBoardService {
	int insertBoard(BoardDto boardDto);
}
